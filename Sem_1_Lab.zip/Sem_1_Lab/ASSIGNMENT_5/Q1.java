import java.util.Scanner;
public class Q1 {
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println("Enter first number:");
int a=sc.nextInt();
System.out.println("Enter second number:");
int b=sc.nextInt();
int sum=0;
for (int i=1;i<a;i++)
{
	if(a%i==0) {
		sum=sum+i;
	}
	
}

int sum2=0;
for (int i=1;i<b;i++)
{
	if(b%i==0) {
		sum2=sum2+i;
	}
	
}

if(sum==b && sum2==a) {
	System.out.println(a+" and "+b+" are amicable numbers.");
}
else {
	System.out.println(a+" and "+b+" are not amicable numbers.");
}
	}

}
