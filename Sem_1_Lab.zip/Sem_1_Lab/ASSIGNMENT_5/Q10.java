import java.util.Scanner;
public class Q10 {
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println("Enter n");
int n=sc.nextInt();
int a=0;
int b=1;
int c=1;
System.out.print(a+","+b+","+c);
int d;
for(int i=1;i<=n;i++) {
	d=a+b+c;
	System.out.print(","+d);
	a=b;
	b=c;
	c=d;
}
}
}
