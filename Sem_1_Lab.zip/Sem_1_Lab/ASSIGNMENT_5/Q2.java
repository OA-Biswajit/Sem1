import java.util.Scanner;
public class Q2 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number:");
int num=sc.nextInt();
int num2=num;
int c=0; // if c=0 prime ,if c=1 not prime
int d=0;
int rev=0;
for(int i=2;i<=num/2;i++)
{
	if(num%i==0) {
		c=1;
	break;
	}
}
		while(num>0) {
			int rem=num%10;
			rev=rev*10+rem;
			 num=num/10;
		}
		for(int k=2;k<=rev/2;k++) {
			if(rev%k==0) {
				d=1;
			break;
		}
	}
if(c==0 && d==0) {
	System.out.println(num2+" is twisted prime");
}
else {
	System.out.println(num2+" is not a twisted prime");
}

}
}