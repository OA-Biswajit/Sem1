import java.util.Scanner;
public class Q3 {
public static void main(String[] args) {

			Scanner sc = new Scanner(System.in);
			int a, b,flag;
			System.out.print("Enter lower bound of the interval: ");
			a = sc.nextInt();
			System.out.print("\nEnter upper bound of the interval: ");
			b = sc.nextInt(); 
			System.out.printf("\nPrime numbers between %d and %d are: ", a, b);
	 			
			for (int i = a; i <= b; i++) {
				if ( i == 1 || i == 0)
					continue;
				flag = 0;
	 
				for (int j = 2; j <= i / 2; j++) {
					if (i % j == 0) {
						flag = 1;
						break;
					}
				}
				if (flag == 0)
					System.out.print(i+" ");
			}
    }
}