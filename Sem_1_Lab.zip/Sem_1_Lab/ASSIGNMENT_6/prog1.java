import java.util.*;
public class prog1{
	public static void main(String [] args)
	{
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the operator: ");

	char opt =sc.next().charAt(0);

	switch(opt)
		{
	
			case '+':
			{
				System.out.println("Enter two number: ");
			int x=sc.nextInt();
			int y=sc.nextInt();
		
			System.out.println(additionSimple(x,y));
			break;
			}

			case '-':
			{
				System.out.println("Enter two number: ");
			int x=sc.nextInt();
			int y=sc.nextInt();
			
			System.out.println(subtractionSimple(x,y));
			
			break;
			}
			
			case '*':
			{
				System.out.println("Enter two number: ");
			int x=sc.nextInt();
			int y=sc.nextInt();
			
			System.out.println(multiplicationSimple(x,y));
			
			break;
			}

			case '/':
			{
				System.out.println("Enter two number: ");
				double x=sc.nextDouble();
				double y=sc.nextDouble();
			if(x!=0){
			
			System.out.println(divisionSimple(x,y));
			}
			else
			System.out.println("Undefine");
			break;
			}
			case '%':
			{
				System.out.println("Enter two number: ");
				
				double x=sc.nextDouble();
				double y=sc.nextDouble();
			
			
			System.out.println(remainderSimple(x,y));
			
			break;
			}
			case 'n':
			{
				System.out.println("Enter the number: ");
				int n=sc.nextInt();
		
			System.out.println(squareRootSimple(n));
			
			break;
			}
			

		}
	}

	public static int additionSimple(int x, int y)
	{
	y=y+x;
	return y;
	}

	public static int subtractionSimple(int x, int y)
	{
	y=y-x;
	return y;
	}

	public static int multiplicationSimple(int x, int y)
	{
	y=y*x;
	return y;
	}

	public static double divisionSimple(double x, double y)
	{
		
		y=y/x;
		return y;
		
	}

	public static double remainderSimple(double n,double m)
	{
		n=n%m;
		
		return n;
	}
	public static double squareRootSimple(int n)
	{
	return Math.sqrt(n);
	}

}
