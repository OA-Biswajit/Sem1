import java.util.Scanner;
public class Q3 {
	public static int reverse(int number)
	{
		int rem=0,rev=0;
		while(number>0)
		{
			rem=number%10;
			rev = rev*10+rem;
			number=number/10;
		}
		
		return rev;
		 
	}
	public static boolean isPalindrome(int number)
	{
		if(reverse(number)==number)
			return true;
		else 
			return false;
	}


	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int number = sc.nextInt();
		boolean result=isPalindrome(number);
		System.out.println( number + (result?" is":" is not")+ " a palindrome number.");
	}

}
