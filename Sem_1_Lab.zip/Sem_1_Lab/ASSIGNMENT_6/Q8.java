import java.util.*;
public class Q8 
{
	public static boolean palindrome(String str)
	{
		
		String s="";
		for(int i=1;i<=str.length();i++)
		{
			s = s+str.charAt(str.length()-i);
		}
		if(s.equals(str))
			return true;
		else
			return false;
	}

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String str = sc.nextLine();
		System.out.println(str + (palindrome(str)?" is ":" is not ")+
		 " palindrome. ");
	}

}
