
public class prog1 {
	public static void main(String[]args) {
		System.out.print("Hello \"ITERIAN\" Welcome to" +
				" Siksha 'O' Anusandhana Family Welcome to \"Introduction" +
				" to Computer laboratory\" Java is fun for All!!  ");	
	}

}
