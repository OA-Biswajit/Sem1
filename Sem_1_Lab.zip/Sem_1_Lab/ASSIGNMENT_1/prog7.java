public class prog7 {
	public static void main(String[] args) {
	int x=10;
	int y=20;
	int z;
	System.out.println("value of x and y before swaping "+x+" "+y);
	z=x;
	x=y;
	y=z;
	System.out.println("value of x and y after swaping "+x+" "+y);
	}
}