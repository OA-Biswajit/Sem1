public class prog5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String name="Hey Rishi, ";
	String greet="Good Morning!";
	System.out.println(name+greet);
	}

}
