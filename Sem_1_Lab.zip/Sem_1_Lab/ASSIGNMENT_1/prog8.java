public class prog8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=10;
		int y=20;
		System.out.println("value of x and y before swaping "+x+" "+y);
		x=x+y;
		y=x-y;
		x=x-y;
		System.out.println("value of x and y after swaping "+x+" "+y);
	}

}
