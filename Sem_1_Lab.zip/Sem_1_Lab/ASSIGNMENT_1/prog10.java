public class prog10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String ruler1="1";
System.out.println(ruler1);
ruler1=ruler1+"2"+ruler1;
System.out.println(ruler1);
ruler1=ruler1+"3"+ruler1;
System.out.println(ruler1);
ruler1=ruler1+"4"+ruler1;
System.out.println(ruler1);
	}

}
