public class prog9 {
	public static void main(String[] args) {
		System.out.println(5);
		System.out.println((float)25/6);
		System.out.println(5+'6'); 
		System.out.println(5+7+'9');
		System.out.println("92"+7+5);
		System.out.println(2+"9");
}
}
