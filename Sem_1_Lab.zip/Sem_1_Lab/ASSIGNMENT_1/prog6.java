
public class prog6 {
	public static void main(String[] args) {
	int AccountNo=123456;
	String name="Biswajit kumar senapati";
	double balance=7654.98;
	System.out.print("My name is "+name
			+" bearing account number "+AccountNo
			+" havaing balance "+balance+"\"");
}
}
