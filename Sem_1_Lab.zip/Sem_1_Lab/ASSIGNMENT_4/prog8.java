import java.util.*;
public class prog8{
public static void main (String args []){
Scanner sc=new Scanner(System.in);
		int a,b;
		do
		{
			System.out.println("User guesses");
			a=sc.nextInt();
			b=(int)((10-1)*Math.random()+1);
			System.out.println("Computer guesses:"+b);
			if(b>a)
				System.out.println("Too high,Try again");
			else if(b<a)
				System.out.println("Too low,Try again");
			else if(a==b)
			{
				System.out.println("Good guess");
				break;
			}
		}while(b!=a);
		System.out.println("program end");
	}


}
