import java.util.*;
public class prog7 {
public static void main (String args [] )
{
     Scanner sc =new Scanner (System.in);
System.out.print("Enter a no. for which you want to find the multiplication table: ");
int a=sc.nextInt();
for (int i=1;i<11;i++){

System.out.println(a+" x "+i+"="+a*i);

}
}
}
