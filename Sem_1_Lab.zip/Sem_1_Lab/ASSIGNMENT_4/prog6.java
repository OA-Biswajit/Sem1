import java.util.*;
public class prog6 {
public static void main (String args []){

	Scanner sc=new Scanner(System.in);
		int pro=1;
		System.out.println("enter two numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		for(int i=1;i<=b;i++)
		{
			pro=pro*a;
		}
		System.out.println(a+" to the power "+ b +"="+pro);
}
}
