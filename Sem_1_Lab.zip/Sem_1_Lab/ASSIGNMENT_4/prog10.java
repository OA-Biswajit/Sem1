import java.util.*;
public class prog10
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int n= sc.nextInt();
		int b=0;
			for (int i=1;i<=n/2;i++)
			{
				b=(int)Math.pow(3, i);
				if(b>=n/2)
				 break;
			}
		System.out.println("The largest mulitiple of 3 less than or equal to "+b);

	}

}
