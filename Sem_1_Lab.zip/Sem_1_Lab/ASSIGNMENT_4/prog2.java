import java.util.*;
public class prog2{
	public static void main (String args [])
	{
		Scanner sc =new Scanner (System.in);
		int n= sc.nextInt();
		int n1=n;
		int sum= 0;
		while(n!=0){
		sum+=n%10;
		n=n/10;
	}
		System.out.println(sum);
		if(sum%9==0)
System.out.println("The number "+n1+" is divisible by 9.");

	}

}
