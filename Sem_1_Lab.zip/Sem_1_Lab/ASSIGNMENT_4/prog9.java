import java.util.*;
public class prog9
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		int num2=num;
		int rev=0,r=0;
		while(num!=0)
		{
			 r=num%10;
			if(r!=0)
				rev=rev*10+r;
			num=num/10;
		}
		while(rev!=0)
		{
			 r=rev%10;
			num=num*10+r;
			rev=rev/10;
		}
		System.out.println("After removing 0 from the number "
		+num2+" the new number is "+num);
	}

}
