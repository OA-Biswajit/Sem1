import java.util.Scanner;
public class prog1
{
	public static void main (String args [])
	{
		Scanner sc =new Scanner(System.in);
		int sum=0;
		System.out.println("ENTER FIRST NUMBER ");		
		int num1=sc.nextInt();
		System.out.println("ENTER SECOND NUMBER ");
		int num2=sc.nextInt();
		System.out.println("ENTER THIRD NUMBER ");
		int num3=sc.nextInt();	

		for (int i=num1;i<=num2;i=i+num3){		
		
		System.out.println(i+" ");
		sum+=i;
		}
		System.out.println(sum);
						
	}
}
