 import java.util.*;
public class prog4{
	public static void main (String args [])
	{
		Scanner sc=new Scanner(System.in);
		int r,a,b,num1,num2;
		System.out.println("Enter two numbers");
		num1=sc.nextInt();
		num2=sc.nextInt();
		if(num1>num2){
			a=num1;
			b=num2;
		}
		else {
			a=num2;
			b=num1;
		}
		
		do
		{
			r=a%b;  
			a=b;
			b=r;
		}while(r!=0);
		System.out.println("GCD="+a);
		
	}

}
