public class prog3{
    public static void main(String [] args){
    int c=Integer.parseInt(args[0]);

    int x=(int)((Math.random()*c)+1);
    int y=(int)((Math.random()*c)+1);
    System.out.println("Integer1-"+x +"\nInteger2-"+y);
    int sum=x+y;
    System.out.println("sum="+sum);

   
    }
}
