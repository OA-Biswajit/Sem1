public class prog6{
    public static void main(String[] args) {
        char a=args[0].charAt(0);
        System.out.println((int)a);
    }
}