public class prog4 {
    public static void main(String[] args) {
        // cos (5t) + sin (7t)
        double t = Double.parseDouble(args[0]);
        double sum = (Math.cos(5 * t)) + (Math.sin(7 * t));
        System.out.println("sum = " + sum);

    }
}
