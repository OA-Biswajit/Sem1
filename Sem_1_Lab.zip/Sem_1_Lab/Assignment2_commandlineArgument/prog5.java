public class prog5{
      public static void main(String args []){ 
       int a=Integer.parseInt(args[0]);
       int b=Integer.parseInt(args[1]);
       int c=Integer.parseInt(args[2]);
       int maximum=Math.max(c,Math.max(a,b));
       int Minimum=Math.min(c,Math.min(a,b));
       int middle = (a+b+c)-maximum-Minimum;
       System.out.println("Ascending order of numbers");
       System.out.println(maximum);
       System.out.println(middle);
       System.out.println(Minimum);
     }
}
