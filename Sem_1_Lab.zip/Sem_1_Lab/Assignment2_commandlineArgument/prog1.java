public class prog1{
    public static void main(String [] args){
    
    int x=Integer.parseInt(args[0]);
    int y=Integer.parseInt(args[1]);

    System.out.println("Input integer1-"+x); 
    System.out.println("Input integer2-"+y);
    
    int quotient =x/y;
    int remainder=x%y;

    System.out.println("quotient"+quotient);
    System.out.println("remainder"+remainder);
    }
}
