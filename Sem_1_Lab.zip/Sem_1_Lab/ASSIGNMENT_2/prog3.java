import java.util.Scanner;
public class prog3{
	public static void main(String Args[])
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the basic salary");
		double bs=sc.nextDouble();
		double hra,da,Gross;
		da=0.04*bs;
		hra=0.2*bs;
		Gross =da+hra+bs;
		System.out.println("Da "+da);
		System.out.println("HRA "+hra);
		System.out.println("Gross_Salary "+Gross);
	}
}
