import java.util.Scanner;
public class prog7{
	public static void main(String Args[])
	{
		Scanner sc =new Scanner(System.in);
		int a=1;
		int b=2;
		System.out.println("a"+"    "+"b"+"    "+"    "+"pow(a,b)");
		System.out.println(a+"    "+b+"    "+"    "+(int)Math.pow(a,b));
		a++;b++;
		System.out.println(a+"    "+b+"    "+"    "+(int)Math.pow(a,b));
		a++;b++;
		System.out.println(a+"    "+b+"    "+"    "+(int)Math.pow(a,b));
		a++;b++;
		System.out.println(a+"    "+b+"    "+"    "+(int)Math.pow(a,b));
		a++;b++;
		System.out.println(a+"    "+b+"    "+"    "+(int)Math.pow(a,b));
		


	}
}
