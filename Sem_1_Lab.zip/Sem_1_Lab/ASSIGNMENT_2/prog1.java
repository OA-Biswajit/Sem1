import java.util.Scanner;
public class prog1{

	public static void main (String []args){

		Scanner sc=new Scanner (System.in);
		double faren =sc.nextDouble();
		double c=(faren-32)*(5.0/9.0);
		System.out.println("Temperature in celsius "+c);
	 }
}
