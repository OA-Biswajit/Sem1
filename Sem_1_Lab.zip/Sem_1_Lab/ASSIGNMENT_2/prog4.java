import java.util.Scanner;
public class prog4{
	public static void main(String Args[])
	{
		Scanner sc =new Scanner(System.in);
		int num= sc.nextInt();
int rem1 = num%10;
num=num/10;

int rem2 = num%10;
num=num/10;

int rem3 = num%10;
num=num/10;

int sum =rem1+rem2+rem3;
System.out.println(sum);

	}
}
