import java.util.Scanner;
public class prog5{
	public static void main(String Args[])
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the radius");
		double radius= sc.nextDouble();
		double surface_Area,Volume;
		surface_Area=3*Math.PI*radius*radius;
		Volume =(2.0/3)*Math.PI*radius*radius*radius;
		System.out.println("surface_Area "+surface_Area);
		System.out.println("Volume "+Volume);
	}
}
