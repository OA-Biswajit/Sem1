import java.util.Scanner;
public class prog6{
	public static void main(String Args[])
	{
		Scanner sc =new Scanner(System.in);
		float t=sc.nextFloat();
		double g=32.174;
		double d=(1.0/2)*g*(t*t);
	 	System.out.println("Distance= "+d);
	}
}
