import java.util.Scanner;
public class prog2{
	public static void main(String Args[])
	{
	//	1 km = 1000meter ,1 km =3280.8399feet ,1 km=39370.0787 inch,1 km = 100000 centimeture
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the distance in km = ");
		long km=sc.nextLong();
		long meters= km*1000;
		double feet=km*3280.8399;
		double inch=km*39370.0787;
		long centimetres=km*100000;
  		System.out.println(km);

		System.out.println(km+"km is "+meters+" meters");

		System.out.println(km+"km is "+feet+" feet");

		System.out.println(km+"km is "+inch+"inch");

		System.out.println(km+"km is "+centimetres+"centimetres");
	}
}
