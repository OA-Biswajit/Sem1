import java.util.Scanner;
public class prog9 
{
	public static void main(String[] args) 
	{	
            Scanner obj = new Scanner (System.in);
            System.out.println(" Enter the value of a , b , c ");
            int a , b , c ,max , min , mid ;
            a=obj.nextInt();
            b=obj.nextInt();
            c=obj.nextInt();
            max=Math.max(Math.max(a,b),c);
            min=Math.min(Math.min(a,b),c);
            mid=a+b+c-max-min;
            System.out.println("Largest number : " +max);
            System.out.println("2nd Largest number : " +mid);
                      
	}

}
