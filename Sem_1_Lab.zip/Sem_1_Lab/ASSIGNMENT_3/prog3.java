import java.util.*;
public class prog3{
	public static void main(String args []){
	Scanner sc =new Scanner(System.in);
System.out.println("Input first number: "); 		
int first=sc.nextInt();
System.out.println("Input second number: "); 
int second=sc.nextInt();
System.out.println("Input thirdnumber: "); 
int third=sc.nextInt();

	if 	((first<second)&&(second<third))
		System.out.println("Increasing");
	else if ((first>second)&&(second>third))
		System.out.println("Decreasing");
	else
		System.out.println("Neither Increasing nor decreasing");

	}
}

