import java.util.*;
public class prog1{
	public static void main(String args []){
	Scanner sc =new Scanner(System.in); 		
	int AGE=sc.nextInt();
	if (AGE>=18)
		System.out.println("You are eligible to caste your vote");
	else 
		System.out.println("you are not not eligible to caste your vote");
	}
}

