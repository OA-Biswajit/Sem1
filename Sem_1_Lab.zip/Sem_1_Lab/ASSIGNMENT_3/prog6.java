import java.util.*;
public class prog6{
	public static void main(String args []){

		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no of units: ");
		int unit=sc.nextInt();
		
		if (unit<=50)
			System.out.println("Electricity bill is =" +(unit*3));
		
		else if ((unit>50) && (unit<=200))
			System.out.println("Electricity bill is ="+((50*3)+(unit-50)*4.80));
		
		else if ((unit>200) && (unit<=400))
			System.out.println("Electricity bill is ="+((50*3)+(150*4.80)+(unit-200)*5.80));
			
		else if (unit>400)		
			System.out.println("Electricity bill is ="+((50*3)+(150)*(4.80)+(200)*(5.80)+(unit-400)*6.20));

	}
}
