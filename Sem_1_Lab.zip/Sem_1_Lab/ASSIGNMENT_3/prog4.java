import java.util.*;
public class prog4{
	public static void main(String args []){

		Scanner sc =new Scanner(System.in);
		int random =(int)(9*Math.random()+1);	
		System.out.print("Enter the user input:");
		int input =sc.nextInt();
		System.out.println("coputer input ="+random);

 		if (input==random) 
		System.out.println("You got it right");

		else if ((random==(input+1)) || (random==(input-1)))
		System.out.println("Almost got it");
		
		else 
		System.out.println("You got it wrong");

	}
}



