import java.util.Scanner;
public class prog8
{
	public static void main(String[] args) 
	{	
     Scanner sc= new Scanner (System.in);
     System.out.print("enter the x coordinate: ");
     double x= sc.nextDouble();
     System.out.print("enter the y coordinate: ");
     double y=sc.nextDouble();
     if(x>0 && y>0)
     {
    	 System.out.println("("+x+ " , " +y+" )"+" is in  quadrant 1");
     }
     else if(x==0 && y>0)
     {
    	 System.out.println("("+x+ " , " +y+" )"+" is on y-axis");
     }
     else if(x==0 && y<0)
     {
    	 System.out.println("("+x+ " , " +y+" )"+" is on -y-axis");
     }
     else if( x<0 && y==0)
     {
    	 System.out.println("("+x+ " , " +y+" )"+" is on -x-axis");
     }
     else if( x>0 && y==0)
     {
    	 System.out.println("("+x+ " , " +y+" )"+" is on x-axis");
     }
     
     else if(x<0 && y>0)
     {
    	 System.out.println("("+x+ " , " +y+" )"+" is in quadrant 2");
     }
     else if (x<0 && y<0)
     {
    	System.out.println("("+x+ " , " +y+" )"+" is in quadrant 3");
     }
     else if (x>0 && y<0)
     {
    	 System.out.println("("+x+ " , " +y+" )"+ " is in quadrant 4");
     }
	}

}
