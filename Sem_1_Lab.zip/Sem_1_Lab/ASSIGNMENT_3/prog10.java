import java.util.Scanner;
public class prog10 
{
	public static void main(String[] args) 
	{	
     Scanner sc=new Scanner(System.in);
     System.out.println("enter the marks");
     int m=sc.nextInt();
     m=m/10;
     switch(m)
     {
     case 10:
     case 9:
     System.out.println("O grade");
     break;
     case 8:
    	 System.out.println("a grade");
    	 break;
     case 7:
    	 System.out.println("b grade");
    	 break;
     case 6:
    	 System.out.println("c grade");
    	 break;
     case 5:
    	 System.out.println("d grade");
    	 break;
     case 4:
    	 System.out.println("e grade");
    	 break;
    	 default:
    		 System.out.println("f grade");
     }
	}

}
