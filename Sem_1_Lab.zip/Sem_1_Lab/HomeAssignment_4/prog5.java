import java.util.*;
public class prog5 {
    public static void main(String[] args) {
        Scanner sc =new Scanner (System.in);
        System.out.print("Enter a number : ");
        int N=sc.nextInt();
        String ruler=" ";
        for (int i = 1; i <= N; i++) {
            ruler=ruler+i+ruler;
            System.out.println(ruler);
           
        }
    }
}