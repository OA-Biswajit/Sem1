import java.util.*;
public class prog4 {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("Input : ");
        int N=sc.nextInt();
        int sum=0;
        int product=1;
        for (int i = 1; i <= N; i++) {

            if (i%2!=0) 
                product *=i;                
            
            else 
                    sum +=i;
                            
        }
        System.out.println("Sum = "+sum);
        System.out.print("Product ="+product);
    
    }
}
