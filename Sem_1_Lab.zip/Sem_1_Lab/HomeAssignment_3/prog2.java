import java.util.Scanner;
public class prog2 {

    public static void main(String[] args) {
        Scanner sc =new Scanner (System.in);
        System.out.println("Enter today's day: ");
        int today=sc.nextInt();
        
        System.out.println("Enter the number of days elapsed since today: ");
        int future=sc.nextInt();
        
        switch (today%7) {
            case 0:
                System.out.println("Today is Sunday");
                break;
            case 1: 
                System.out.println("Today is Monday");
                break;
            case 2:
                System.out.println("Today is Tuesday");
                break;
            case 3:
                System.out.println("Today is Wednesday");
                break;
            case 4:
                System.out.println("Today is Thursday");
                break;
            case 5:
                System.out.println("Today is Friday");
                break;
            case 6:
                System.out.println("Today is Saturday");
                break;
           
        }
        switch (future%7) {
            case 0:
                System.out.println(" and the future day is Sunday");
                break;
            case 1: 
                System.out.println(" and the future day is Monday");
                break;
            case 2:
                System.out.println(" and the future day is Tuesday");
                break;
            case 3:
                System.out.println(" and the future day is Wednesday");
                break;
            case 4:
                System.out.println(" and the future day is Thursday");
                break;
            case 5:
                System.out.println(" and the future day is Friday");
                break;
            case 6:
                System.out.println(" and the future day is Saturday");
                break;
           
        }
    }
}