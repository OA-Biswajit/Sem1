import java.util.Scanner;
public class prog1 {

    public static void main(String[] args) {
        Scanner sc =new Scanner (System.in);
        System.out.println("(scissor (0), rock (1), paper (2)):");
        System.out.print("Enter a num to play ");
        int user=sc.nextInt();
            
        int comp=(int)(Math.random()*3);
        System.out.println("Computer input :"+comp);
          
            if (user==comp)
                System.out.println("draw");
            
            else if((user==0 && comp==1)||(user==1 && comp==2) ||(user==2 && comp==0))
            
                System.out.println("You lose");
            
            else 
                System.out.println("You win");
            
                    
    }
}