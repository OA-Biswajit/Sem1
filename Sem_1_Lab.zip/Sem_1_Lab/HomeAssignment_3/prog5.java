public class prog5 {
  public static void main(String[] args) {
    
  }  
}
